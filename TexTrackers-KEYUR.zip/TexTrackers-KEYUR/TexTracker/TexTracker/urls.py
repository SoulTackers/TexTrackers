"""TexTracker URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from Employee.views import Employee_view
from FeesInward.views import Feesinward_view
from Invoice.views import Invoice_view
from Outward.views import Outward_view
from PendingWork.views import PendingWork_view
from Inward.views import Inward_view


urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url('feesinward/',Feesinward_view),
    url('employee/',Employee_view),
    url('Invoice/',Invoice_view),
    url('Inward/',Inward_view),
    url('Outward/',Outward_view),
    url('PendingWork/',PendingWork_view)
]
