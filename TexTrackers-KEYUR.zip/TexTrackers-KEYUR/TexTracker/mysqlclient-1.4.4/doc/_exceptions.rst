_exceptions Module
========================

.. automodule:: MySQLdb._exceptions
    :members:
    :undoc-members:
    :show-inheritance:
